Left 4 Downtown Sourcemod Extension
---------- version 0.4.6.0

Installation:
* Extract files into /left4dead2/addons/sourcemod/

----------

CVARS:

* l4d_maxplayers - (default: -1) Override the in-game max player count (up to 18)

----------

NOTES:

* l4d_maxplayers is restricted to <= maxplayers as set on command line. If you cannot go above 8, buy more slots from your GSP.