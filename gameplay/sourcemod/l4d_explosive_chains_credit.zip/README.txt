[L4D & L4D2] Explosive Chains Credit (1.3) [26-Nov-2021]

https://forums.alliedmods.net/showthread.php?t=334655

Installation:

1. Click "Get Plugin" and put the .smx file into your servers \addons\sourcemod\plugins\ folder.