[L4D/L4D2]ThirdPersonShoulder_Detect(1.5.3 - 08/06/2020)

https://forums.alliedmods.net/showthread.php?t=298649