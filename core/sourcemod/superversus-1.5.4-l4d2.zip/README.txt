SuperVersus 1.5.4

https://forums.alliedmods.net/showthread.php?p=830069

Installation:

1. Copy l4d_superversus.smx to addons/sourcemod/plugins/
2. Modify l4d_superversus.cfg in cfg/sourcemod/ (If the file does not exist it will be created when the plugin is first loaded or you can download a fresh copy of the config below)